<?php
/**
 * Created by PhpStorm.
 * User: minhvong
 * Date: 5/28/18
 * Time: 8:59 PM
 */

return [
    'SPEED_SMS_API_ACCESS_TOKEN' => 'ZcaZphDij5R4JBsTUsJkFCrF7oPnuT_H',
    'SPEED_SMS_API_SECRET_KEY' => 'f264e6fd3269b92981945dd654c1395026bb55fd'
];